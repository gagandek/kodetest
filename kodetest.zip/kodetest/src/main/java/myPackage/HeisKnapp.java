package myPackage;

public class HeisKnapp extends Knapp{
    String [] knapper; //alle etg knapper i heisen
    boolean alarmKnapp;

    /**mulig å legge til andre typer knapper her.*/

    public HeisKnapp() {
        super();
        knapper = new String[8]; //totalt 8 etg
        alarmKnapp = false; //deaktivert som default

       for(int i=0; i<knapper.length; i++){
           knapper[i] = i +"";
       }
    } 

    public void setKnapper(String[] knapper) {
        this.knapper = knapper;
    }

    public void setAlarmKnapp(boolean alarmKnapp) {
        this.alarmKnapp = alarmKnapp;
    }

    public String[] getKnapper() {
        return knapper;
    }

    public boolean getAlarmKnapp() {
        return alarmKnapp;
    }
    
   
}
