package myPackage;
import java.lang.Math;

public class HeiskontrollSystem {
    final Heis heis;
    final Etasje[] etasje;

    public HeiskontrollSystem(){
        //initiate variables here
        heis = new Heis(); //assumption: only one lift in the building
        etasje = new Etasje[8]; //assumption: there are only 8 floors
    }

    public static void main(String[] args) {
        System.out.println("Starter HeiskontrollSystem...");


        /**  Test kallene til metoder;
         * 
        new HeiskontrollSystem().tilBestemtEtg(5);
        System.out.println(new HeiskontrollSystem().returnerKjoreretning(new Etasje(4), new Etasje(4)));
        System.out.println(new HeiskontrollSystem().estimerTidTilAngittEtg(new Etasje(5), new Etasje(4)));
        new HeiskontrollSystem().nodsstopp();
         */
    }


    public void tilBestemtEtg(int destinasjonEtg){
        /** trykker på en destinasjons etasje i en heis */

        System.out.println("Til etasjen: " + heis.heisknapper.knapper[destinasjonEtg]);
    }

    public String returnerKjoreretning(Etasje denne, Etasje trykkket){
       if(denne.etgNummer< trykkket.etgNummer){
            return "Heisen på vei opp";
       }else if(denne.etgNummer> trykkket.etgNummer){
           return "Heisen på vei ned";
       }else if(denne.etgNummer == denne.etgNummer){
           return "Heisen er på nåværende etasje";
       }
       return null;
    }

    public String estimerTidTilAngittEtg(Etasje denne, Etasje angitt){
        int tid = (denne.etgNummer - angitt.etgNummer);
        return "Du er " + Math.abs(tid) + " etasjer unna angitt etasje" ;
    }

    public void nodsstopp(){
        heis.heisknapper.setAlarmKnapp(true);
        System.out.println("Alarm aktivert");
    }
}
