package myPackage;

public enum Vegg {
}
