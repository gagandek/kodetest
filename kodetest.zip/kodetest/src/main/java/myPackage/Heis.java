package myPackage;

public class Heis {
    HeisKnapp heisknapper; //knapper i heisen

    public Heis(){
        heisknapper = new HeisKnapp();
    }

    public HeisKnapp getKnapper() {
        return heisknapper;
    }

}
