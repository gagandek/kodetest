package myPackage;

public class Etasje {
    final int etgNummer;

    public Etasje(int etgNummer) {
        this.etgNummer = etgNummer;
    }
}
