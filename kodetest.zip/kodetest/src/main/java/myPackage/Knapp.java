package myPackage;

public class Knapp {
    Knapp() {
    }
}
