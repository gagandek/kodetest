package myPackage;

public class VeggKnapp extends Knapp{
    String oppKnapp;
    String nedKnapp;

    public VeggKnapp(String knappLabel) {
        super();
        oppKnapp = new String("Opp");
        nedKnapp = new String("Ned");
    }
}
